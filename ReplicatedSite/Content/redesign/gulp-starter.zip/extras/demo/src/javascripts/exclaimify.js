export default (string) => `${string}!`
