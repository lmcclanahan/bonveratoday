import exclaimify from './exclaimify'

console.log(exclaimify('page2.js loaded'))
