export default 'I was loaded async'
