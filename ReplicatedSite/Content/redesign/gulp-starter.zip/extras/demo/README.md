To run this demo, check out the demo branch!

```bash
git checkout demo
npm start
```

Or move this src folder to the root of the project, and replace `gulpfile.js/config.json` with the one in this folder.

```bash
rm -rf ./src gulpfile.js/config.json && mv ./extras/demo/src ./src && mv ./extras/demo/config.json gulpfile.js/config.json
```
