﻿function openNav() {
    document.getElementById("bonveraSidenav").style.width = "85%";    
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("bonveraSidenav").style.width = "0";
    document.body.style.backgroundColor = "rgba(0,0,0,0)";
}