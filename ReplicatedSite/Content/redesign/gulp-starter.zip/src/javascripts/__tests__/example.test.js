// See http://chaijs.com/ for assertion style docs
describe('something', () => {
  it('does some stuff', () => {
    assert.isTrue(true)
  })
})
